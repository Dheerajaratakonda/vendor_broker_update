import React from 'react';
import FormGroup from 'react-bootstrap/lib/FormGroup';
import Button from 'react-bootstrap/lib/Button';
import NavBar1 from '../admin welcome/navbar.jsx';
import Unassigned from './unassigned_report.jsx';

class VendorBroker extends React.Component{
	constructor(props){
		super(props);
		this.name=this.props.location.state.data;
		this.group=this.props.location.state.group;
		console.log("d1", this.name)
	}
	

  

	render(){
		return 	<div className="container-fluid">
					<NavBar1 name={this.name} group={this.group}/> <br/>
					<span>click on button to download</span>
					<div> <Unassigned /> </div>
					
					<br/><br/><br/><br/>
				</div>
	
}

}
export default VendorBroker;