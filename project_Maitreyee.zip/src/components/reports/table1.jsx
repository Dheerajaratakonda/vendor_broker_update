import React from 'react';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';

const products = [];

const data= {
                data1:[
           {"id":1,"first_name":"William","last_name":"Elliott","email":"welliott0@wisc.edu",
             "country":"Argentina","ip_address":"247.180.226.89"},
              {"id":2,"first_name":"Carl","last_name":"Ross","email":"cross1@mlb.com",
             "country":"South Africa","ip_address":"27.146.70.36"},
              {"id":3,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
                                                  {"id":4,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
            
                                                  {"id":5,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
                                                
                                                 
                                                  {"id":9,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             
                                                  {"id":10,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             
                                                 
                                                  {"id":6,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             
                                                  {"id":8,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             {"id":11,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
                                                
                                                  {"id":5,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
                                                
                                                 
                                                  {"id":9,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             
                                                  {"id":10,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             
                                                 
                                                  {"id":6,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             
                                                  {"id":8,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"},
             {"id":11,"first_name":"Jeremy","last_name":"Scott","email":"jscott2@cbsnews.com",
             "country":"Colombia","ip_address":"103.52.74.225"}
     ]
};
function addProducts() {
  for (let i = 0; i < data.data1.length ; i++) {
  products.push({
                  id: data.data1[i].id,
                  first_name:  data.data1[i].first_name,
                  last_name:  data.data1[i].last_name,
                  email:  data.data1[i].email
  })
  }
}
addProducts();

export default class Table1 extends React.Component {
  render() {
    return (
      <BootstrapTable ref='table' data={ products } pagination  exportCSV
        csvFileName='locations.csv'>
   
        <TableHeaderColumn ref='last_name' dataField='last_name' isKey={ true }dataSort={ true } filter={ { type: 'TextFilter'} } >Vendor</TableHeaderColumn>
        <TableHeaderColumn ref='email' dataField='email' dataSort={ true } filter={ { type: 'TextFilter' } }>Broker</TableHeaderColumn>
                                <TableHeaderColumn ref='last_name' dataField='last_name' dataSort={ true } filter={ { type: 'TextFilter' } }>Market</TableHeaderColumn>
                                <TableHeaderColumn ref='first_name' dataField='first_name' dataSort={ true } filter={ { type: 'TextFilter' } }>Opco</TableHeaderColumn>
                                     <TableHeaderColumn dataField='id'  dataSort={ true }  filter={ { type: 'TextFilter'}}>CMMI 
        </TableHeaderColumn>
        <TableHeaderColumn ref='first_name' dataField='first_name' dataSort={ true } filter={ { type: 'TextFilter' } }>Item</TableHeaderColumn>
      </BootstrapTable>
    );
  }

  handlerClickCleanFiltered() {
    this.refs.id.cleanFiltered();
    this.refs.first_name.cleanFiltered();
    this.refs.last_name.cleanFiltered();
    this.refs.email.cleanFiltered();
    
  }
}
