/* eslint max-len: 0 */
/* eslint no-unused-vars: 0 */
import React from 'react';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import NavBar1 from '../admin welcome/navbar.jsx';


const products = [];

const data= {
	data1:[
    {"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"1234", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"1235", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"1236", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"1237", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"1238", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"1239", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"1230", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12311", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12312", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12313", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12314", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12315", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12316", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12317", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12318", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12319", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12320", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12323", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12324", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12325", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12326", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12327", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12328", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"},
	{"broker":"xyz", "vendor_no":"12329", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"","edate":"","idesc":"olive"}
     ]
};
function addProducts() {
  // console.log(data.data1.length);
  for (let i = 0; i < data.data1.length ; i++) {
	// console.log(data.data1[i].id);
  products.push({
	   vendor_no: data.data1[i].vendor_no,
	   broker: data.data1[i].broker,
	  opco:  data.data1[i].opco,
	  market:  data.data1[i].market,
	  cmim:  data.data1[i].cmim,
	  item:  data.data1[i].item,
	  sdate: data.data1[i].sdate,
	  edate: data.data1[i].edate,
	  idesc: data.data1[i].idesc
  })
  }
}

addProducts();

let arr=[];

function onSelectAll(isSelected, currentDisplayAndSelectedData){
  alert("is select all: " + isSelected);
  alert("Current display and selected data: ");
  for(let i=0;i<currentDisplayAndSelectedData.length;i++){
    console.log(currentDisplayAndSelectedData[i]);
  }
}
var comp;

export default class AllItems extends React.Component {
	constructor(props) {
    super(props);
    this.state = {
      selected: [], startDate:""
    };
	comp=this;
	this.name=this.props.location.state.data;
	this.group=this.props.location.state.group;
  }
getSelectedRowKeys() {
    console.log(this.refs.table.state.selectedRowKeys)
  }
onRowSelect(row, isSelected){
  var rowStr = "";
  console.log(row);
  console.log(comp)
  var ip=document.querySelector(".sdate").value;
  var ip1=document.querySelector(".edate").value;
  row["sdate"]=ip;
  row["edate"]=ip1;
  for(var prop in row){
    rowStr+=prop+": '"+row[prop]+"' ";
  }
  // console.log("is selected: " + isSelected + ", " + rowStr);
  if(isSelected){ 
	  arr.push(rowStr);  
  }
  else{
	  arr.pop(rowStr);
  }
  console.log("hi",arr);
}
    
  

 editFormatter(cell, row){
      return '<input type="date" class="sdate" >';
    }
editFormatter1(cell,row){
return '<input type="date" class="edate" >';
}	
	
	
	

  render() {
	const selectRowProp = {
	  mode: "checkbox",
	  clickToSelect: true,
	  onSelect: this.onRowSelect,
	  onSelectAll: onSelectAll
	}; 	

	const cellEditProp = {
		mode: 'dbclick',
	blurToSave: true
	};
	

    return (
		<div>
  <NavBar1 name={this.name} group={this.group}/><br/><br/><br/><br/>
      <BootstrapTable ref='table' data={ products } selectRow={ selectRowProp }  className="scrollme1" pagination >
	  
        <TableHeaderColumn ref='vendor_no' dataField='vendor_no' isKey={ true } filter={ { type: 'TextFilter' } } dataSort={ true }>Vendor Number</TableHeaderColumn>
        <TableHeaderColumn dataField='broker' ref='broker'   filter={ { type: 'TextFilter'}} dataSort={ true } >Vendor Name
        </TableHeaderColumn>
       
		<TableHeaderColumn ref='item' dataField='item' filter={ { type: 'TextFilter' } } dataSort={ true }  >Item</TableHeaderColumn>
		
		<TableHeaderColumn ref='idesc' dataField='idesc' filter={ { type: 'TextFilter' } } dataSort={ true } >Item description</TableHeaderColumn>
		
        <TableHeaderColumn ref='opco' dataField='opco' filter={ { type: 'TextFilter' } } dataSort={ true } >OPCO</TableHeaderColumn>
		
		<TableHeaderColumn dataFormat={this.editFormatter} filter={ { type: 'TextFilter' } } dataSort={ true } >Start date</TableHeaderColumn>
		
		<TableHeaderColumn ref='edate' dataFormat={this.editFormatter1} dataField='edate' filter={ { type: 'TextFilter' } } dataSort={ true } >End date</TableHeaderColumn>
       
      </BootstrapTable><br/>
	  
	  <button className="btn btn-primary">ADD</button>
	  </div>
    );
  }

  handlerClickCleanFiltered() {
    this.refs.broker.cleanFiltered();
    this.refs.vendor_no.cleanFiltered();
    this.refs.market.cleanFiltered();
    this.refs.cmim.cleanFiltered();
	this.refs.item.cleanFiltered();
	this.refs.opco.cleanFiltered();
	
	this.refs.edate.cleanFiltered();
	this.refs.idesc.cleanFiltered();
  }
}
