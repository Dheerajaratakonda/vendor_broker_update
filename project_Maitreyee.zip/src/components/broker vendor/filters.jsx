/* eslint max-len: 0 */
/* eslint no-unused-vars: 0 */
import React from 'react';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import axios from "axios";

const products = [];
const cellEditProp = {
  mode: 'click'
};
const data= {
	data1:[
           {"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "C++","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"xyz", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","opco":"123","sdate":"01/3/3018","edate":"31/3/2018"}
     ]
};
function addProducts() {
  for (let i = 0; i < data.data1.length ; i++) {
  products.push({
	  vendor_no: data.data1[i].vendor_no,
	   broker: data.data1[i].broker,
	  opco:  data.data1[i].opco,
	  market:  data.data1[i].market,
	  cmim:  data.data1[i].cmim,
	  item:  data.data1[i].item,
	  sdate: data.data1[i].sdate,
	  edate: data.data1[i].edate
  })
  }
}
addProducts();

class ItemTable extends React.Component {
    constructor(props) {
    super(props);
    var row='';
    this.state = {
      name: props.defaultValue,
      open: true,
        data:[]
    };
        
  }
    
    componentWillMount(){
        axios.get('./items.json').then(
            res=>{
                for(var el in res.data){
                    if(res.data[el].name===this.state.name){
                        this.state.data.push(res.data[el]);
                    }
                }
                this.setState({data:this.state.data});
            }
        )
    }
  
  
  close = () => {
    this.setState({ open: false });
    this.props.onUpdate(this.props.defaultValue);
  }
  render() {
    const row=[];
    for (var i in this.state.data){
    row.push(<tr key={i}>
    <td>{this.state.data[i].name}</td>
    <td>{this.state.data[i].year}</td>

    </tr>)
    }
    const fadeIn = this.state.open ? 'in' : '';
    const display = this.state.open ? 'block' : 'none';
    return (
      <div className={ `modal fade ${fadeIn}` } id='myModal' role='dialog' style={ { display } }>
        <div className='modal-dialog'>
          <div className='modal-content'>
            <div className='modal-body'>
              <table>
                  <thead><tr>
                      <th>Item</th>
                      <th>Year</th></tr>
                  </thead>
                  <tbody>
                      {row}
                  </tbody>
                </table>
            </div>
            <div className='modal-footer'>
              
              <button type='button' className='btn btn-default' onClick={ this.close }>Close</button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const createItemTable = (onUpdate, props) => (<ItemTable onUpdate={ onUpdate } {...props}/>);


export default class AllFilters extends React.Component {

  render() {

    return (
      <BootstrapTable ref='table' data={ products } cellEdit={ cellEditProp } pagination className="scrollme1" >
	     <TableHeaderColumn ref='vendor_no' dataField='vendor_no' isKey={ true } filter={ { type: 'TextFilter' } } dataSort={ true }>Vendor Number</TableHeaderColumn>
        <TableHeaderColumn dataField='broker' ref='broker'   filter={ { type: 'TextFilter'}} dataSort={ true }>Vendor Name
        </TableHeaderColumn>
        
     
        <TableHeaderColumn ref='market' dataField='market' filter={ { type: 'TextFilter'} }  dataSort={ true }>Market</TableHeaderColumn>
        <TableHeaderColumn ref='cmim' dataField='cmim' filter={ { type: 'TextFilter' } } dataSort={ true }>CMIM</TableHeaderColumn>
		<TableHeaderColumn ref='item' dataField='item' filter={ { type: 'TextFilter' } } dataSort={ true } customEditor={ { getElement:createItemTable} }>
Item</TableHeaderColumn>
        <TableHeaderColumn ref='opco' dataField='opco' filter={ { type: 'TextFilter' } } dataSort={ true }>OPCO</TableHeaderColumn>
		<TableHeaderColumn ref='sdate' dataField='sdate' filter={ { type: 'TextFilter' } } dataSort={ true }>Start date</TableHeaderColumn>
		<TableHeaderColumn ref='edate' dataField='edate' filter={ { type: 'TextFilter' } } dataSort={ true }>End date</TableHeaderColumn>
      </BootstrapTable>
    );
  }

  handlerClickCleanFiltered() {
    this.refs.broker.cleanFiltered();
    this.refs.vendor_no.cleanFiltered();
    this.refs.market.cleanFiltered();
    this.refs.cmim.cleanFiltered();
	this.refs.item.cleanFiltered();
	this.refs.opco.cleanFiltered();
	this.refs.sdate.cleanFiltered();
	this.refs.edate.cleanFiltered();
    
  }
}
