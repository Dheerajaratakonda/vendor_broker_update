
import React from 'react';
import ReactDOM from 'react-dom';
import axios from 'axios';
 import FormGroup from 'react-bootstrap/lib/FormGroup';
import { BrowserRouter as Router, Route, Link,Switch} from 'react-router-dom';
import NavBar1 from './navbar.jsx';

var comp;

class Login extends React.Component {
	constructor(props){
        
		super(props);
		this.state={data:[]};
		this.name=this.props.location.state.data;
        this.group=this.props.location.state.group;
		this.add=this.add.bind(this);
		
	}
   
    componentWillMount(){
       comp=this;
         $.ajax({
            headers: { 
            'Accept': 'application/json',
            'Content-Type': 'application/json' 
         },   

        'url': './brokerDetails.json',
        'contentType': 'application/json',
        'dataType': 'json',

      })
      .done(function(data) {


        for (var el in data){
            comp.state.data.push({
                code:data[el].code,
                name:data[el].name,
                leadBroker:data[el].leadBroker,
                email:data[el].email
            })
            comp.setState({data:comp.state.data});

        }
      })
      .fail(function(jqXhr) {
        console.log('failed to register');
      });
        }
    
   
add(e){
	   comp.props.history.push({pathname:'/add', state:{data:this.name,group:this.group}});
	
}
  
    
    handleDeleteButtonClick = (onClick) => {
      // Custom your onClick event here,
      // it's not necessary to implement this function if you have no any process before onClick
      onClick();
    }
    createCustomDeleteButton = (onClick) => {
      return (
                
                    <button type="button" id= "delete" className="btn btn-warning react-bs-table-del-btn " onClick={ () => this.handleDeleteButtonClick(onClick)}>
                        <span><i className="glyphicon glyphicon-trash"> </i>Delete</span>
                    </button>
           
      );
    }
    
    
	

        render(){
            const selectRow = {
                mode: 'checkbox' //radio or checkbox
              };
            const options = {
                deleteBtn: this.createCustomDeleteButton,
                onRowClick:  function(row){
                    comp.props.history.push({pathname:'/viewbroker',
                                            state:{
                                                data:comp.name,
                                                group:comp.group,
                                                row:row
                                            }})
                }
            };
      	     return (
						<div className="container">
							<NavBar1 name={this.name} group={this.group}/>
                                <div className="row">
                                    <BootstrapTable ref='table' data={ this.state.data } pagination className="scrollme"  selectRow={selectRow} options={options} deleteRow>
                                        <TableHeaderColumn dataField='code' isKey={ true } dataSort={ true }  filter={ { type: 'TextFilter'}} >Code
                                        </TableHeaderColumn>
                                        <TableHeaderColumn dataField='name' dataSort={ true } filter={ { type: 'TextFilter'} } >Name</TableHeaderColumn>
                                        <TableHeaderColumn dataField='leadBroker' dataSort={ true } filter={ { type: 'TextFilter' } }>Lead Broker</TableHeaderColumn>
                                        <TableHeaderColumn  dataField='email' dataSort={ true } filter={ { type: 'TextFilter' } }>Email</TableHeaderColumn>

                                    </BootstrapTable>
                                    <button className="button button2 btn btn-primary" style={{float:"right"}} onClick={this.add}>+ ADD</button> 
                                </div>
                            </div>

            )
            }

						
						 
    }


export default Login;