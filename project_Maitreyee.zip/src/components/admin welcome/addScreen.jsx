import React from 'react';
import FormGroup from 'react-bootstrap/lib/FormGroup';
import Button from 'react-bootstrap/lib/Button';
import NavBar1 from './navbar.jsx';

class AddRow extends React.Component{
	
	constructor(props){
		super(props)
		this.state={data: {code:'', name:'', leadBroker:'', email:''}}
		this.setEmpState = this.setEmpState.bind(this)
		this.addRows = this.addRows.bind(this)
		this.name=this.props.location.state.data;
		this.group=this.props.location.state.group;
	}
	
	setEmpState(e){
               var field = e.target.name;
               var value = e.target.value;
               this.state.data[field] = value;
               this.setState({ data: this.state.data });
              }
			  
	addRows(e){
               alert('Added Successfully');
              }
	
	render(){
		return 	<div>
						
					<NavBar1 name={this.name} group={this.group}/>
					<br/><br/>
					<div className="class1">
						<div className="row">
							<h3>Add Broker Details</h3>
							<br/>
		
							<form className="form-horizontal col-md-offset-1 col-md-6">
							<br/><br/>
								<FormGroup>
									<div className="col-md-2"><label>Code: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="text" name="code" value={this.state.data.code} onChange={this.setEmpState}/>
									</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-2"><label>Name: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="text" name="name" value={this.state.data.name} onChange={this.setEmpState}/>
									</div>
								</FormGroup><FormGroup>
									<div className="col-md-2"><label>User id: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="text" name="leadBroker" value={this.state.data.leadBroker} onChange={this.setEmpState}/>
									</div>
								</FormGroup><FormGroup>
									<div className="col-md-2"><label>Set password: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="text" name="leadBroker" value={this.state.data.leadBroker} onChange={this.setEmpState}/>
									</div>
								</FormGroup><FormGroup>
									<div className="col-md-2"><label>Email: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="email" name="email" value={this.state.data.email} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-2"><label>Contact no: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="number" name="contactnumber" value={this.state.data.contactnumber} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-2"><label>Contact Name: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="text" name="contactname" value={this.state.data.contactname} onChange={this.setEmpState}/>
						 			</div>
								</FormGroup>
								<div className="col-md-offset-2 col-md-4">
									<Button type="submit" className="btn btn-primary" onClick={this.addRows}> Submit </Button>
								</div>
							</form>
							<div className="col-md-3">
								<img src="./assets/handshake.png" className="handshake" alt="image" />
							</div>
						</div>
						
					</div>
				</div>
	}
}
export default AddRow;