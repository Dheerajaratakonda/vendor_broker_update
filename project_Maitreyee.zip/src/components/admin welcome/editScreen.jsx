import React from 'react';
import ReactDOM from 'react-dom';

import FormGroup from 'react-bootstrap/lib/FormGroup';
import Button from 'react-bootstrap/lib/Button';
import NavBar1 from './navbar.jsx';

class EditScreen extends React.Component{
	
	constructor(props){
		super(props);
		this.state={row:this.props.location.state.row};
		this.name=this.props.location.state.data;
		this.group=this.props.location.state.group;
		
	}
	setEmpState(e){
               var field = e.target.name;
               var value = e.target.value;
               this.state.data[field] = value;
               this.setState({ data: this.state.data });
              }
	editRows(e){
		alert('edited successfully')
	}
	
	render(){
		return 	(<div>
					<NavBar1 name={this.name} group={this.group}/>
					
					<br/><br/><br/><br/><br/>
					<div className="class1">
					<div className="row">
					<h3>Update Broker details</h3>
						<br/><br/><br/>
						<div >
							<form className="form-horizontal col-md-offset-1 col-md-6">
								<FormGroup>
									<div className="col-md-2"><label>Code: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="text" name="code" value={this.state.row.code} onChange={this.setEmpState}/>
									</div>
								</FormGroup>
								<FormGroup>
									<div className="col-md-2"><label>Name: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="text" name="name" value={this.state.row.name} onChange={this.setEmpState}/>
									</div>
								</FormGroup><FormGroup>
									<div className="col-md-2"><label>Email: </label></div>
									<div className="col-md-4">
										<input className="form-control" type="email" name="email" value={this.state.row.email} onChange={this.setEmpState}/>
									</div>
								</FormGroup>
								<div  className="col-md-offset-2 col-md-4">
									<Button type="submit"className=" btn btn-primary" onClick={this.editRows}> Update </Button>
								</div>
							</form>
							<div className="col-md-3">
								<img src="./assets/handshake.png" className="handshake" />
							</div>
						</div>
						</div>
					</div>
				</div>)
	}
}
export default EditScreen;