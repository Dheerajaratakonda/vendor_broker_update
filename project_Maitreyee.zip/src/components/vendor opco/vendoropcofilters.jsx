/* eslint max-len: 0 */
/* eslint no-unused-vars: 0 */
import React from 'react';
import { BootstrapTable, TableHeaderColumn } from 'react-bootstrap-table';
import axios from "axios";

const products = [];
const cellEditProp = {
  mode: 'click'
};
const data= {
	data1:[{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"},
	{"broker":"AC", "vendor_no":"123", "market":'North-East', "cmim": "567", "item": "23","sdate":"01/3/3018","edate":"31/3/2018"}
           
           
     ]
};
function addProducts() {
//  console.log(data.data1.length);
  for (let i = 0; i < data.data1.length ; i++) {
//	console.log(data.data1[i].id);
  products.push({
	  vendor_no: data.data1[i].vendor_no,
	   broker: data.data1[i].broker,
	  opco:  data.data1[i].opco,
	  market:  data.data1[i].market,
	  cmim:  data.data1[i].cmim,
	  item:  data.data1[i].item,
	  sdate: data.data1[i].sdate,
	  edate: data.data1[i].edate
  })
  }
}
addProducts();
class ItemTable extends React.Component {
    constructor(props) {
    super(props);
    var row='';
    this.state = {
      name: props.defaultValue,
      open: true,
        data:[]
    };
        console.log(this.state.name)
        
  }
    
    componentWillMount(){
        axios.get('./items.json').then(
            res=>{
                for(var el in res.data){
                    if(res.data[el].name===this.state.name){
                        this.state.data.push(res.data[el]);
                    }
                }
                this.setState({data:this.state.data});
                console.log(this.state.data)
            }
        )
    }
  
  
  close = () => {
    this.setState({ open: false });
    this.props.onUpdate(this.props.defaultValue);
  }
  render() {
    const row=[];
    for (var i in this.state.data){
    row.push(<tr key={i}>
    <td>{this.state.data[i].name}</td>
    <td>{this.state.data[i].year}</td>

    </tr>)
    }
      console.log(row)
    const fadeIn = this.state.open ? 'in' : '';
    const display = this.state.open ? 'block' : 'none';
    return (
      <div className={ `modal fade ${fadeIn}` } id='myModal' role='dialog' style={ { display } }>
        <div className='modal-dialog'>
          <div className='modal-content'>
            <div className='modal-body'>
              <table>
                  <thead><tr>
                      <th>Item</th>
                      <th>Year</th></tr>
                  </thead>
                  <tbody>
                      {row}
                  </tbody>
                </table>
            </div>
            <div className='modal-footer'>
              
              <button type='button' className='btn btn-default' onClick={ this.close }>Close</button>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

const createItemTable = (onUpdate, props) => (<ItemTable onUpdate={ onUpdate } {...props}/>);

export default class VendorOpcoFilters extends React.Component {
  render() {
    return (
        
      <BootstrapTable ref='table' data={ products } pagination className="scrollme1" cellEdit={ cellEditProp } >
        <TableHeaderColumn ref="vendor_no" dataField='vendor_no' isKey={ true } dataSort={ true }  filter={ { type: 'TextFilter'}}>Vendor No
        </TableHeaderColumn>
        <TableHeaderColumn ref='broker' dataField='broker' dataSort={ true } filter={ { type: 'TextFilter'} } >Vendor Name</TableHeaderColumn>
        <TableHeaderColumn ref='broker' dataField='broker' dataSort={ true } filter={ { type: 'TextFilter' } }>Broker</TableHeaderColumn>
		<TableHeaderColumn ref='market' dataField='market' dataSort={ true } filter={ { type: 'TextFilter' } }>Market</TableHeaderColumn>
		<TableHeaderColumn ref='cmim' dataField='cmim' dataSort={ true } filter={ { type: 'TextFilter' } }>CMIM</TableHeaderColumn>
		<TableHeaderColumn ref='item' dataField='item' dataSort={ true } filter={ { type: 'TextFilter' } } customEditor={ { getElement:createItemTable} }>Item</TableHeaderColumn>
		<TableHeaderColumn ref='sdate' dataField='sdate' filter={ { type: 'TextFilter' } } dataSort={ true }>Start date</TableHeaderColumn>
		<TableHeaderColumn ref='edate' dataField='edate' filter={ { type: 'TextFilter' } } dataSort={ true }>End date</TableHeaderColumn>
		</BootstrapTable>
    );
  }

  handlerClickCleanFiltered() {
	  this.refs.vendor_no.cleanFiltered();
    this.refs.broker.cleanFiltered();
    this.refs.opco.cleanFiltered();
    this.refs.market.cleanFiltered();
    this.refs.cmim.cleanFiltered();
    this.refs.item.cleanFiltered();
	this.refs.sdate.cleanFiltered();
	this.refs.edate.cleanFiltered();
  }
}
